package Aula14_Mesa;

import java.util.ArrayList;
import java.util.Collections;

public class Porto {

    private String nome;
    private ArrayList<Conteiner> listaConteiner = new ArrayList<>();

    public Porto(String nome) {
        this.nome = nome;
    }

    public void addConteiner(Conteiner conteiner){
        listaConteiner.add(conteiner);


    }

    public void mostrarConteiners(){
        Collections.sort(listaConteiner);

        for(int i = 0; i < listaConteiner.size(); i++){
            if (!listaConteiner.get(i).isEmbarcado()){
                System.out.println("Número: " + listaConteiner.get(i).getNumero() +
                        "\tDescrição: " + listaConteiner.get(i).getDescricao());
            }
        }
    }

    public int quantidadeConteinersPerigosos(){
        int contador = 0;

        for (int i = 0; i < listaConteiner.size(); i++){
            if (listaConteiner.get(i).isMaterialPerigoso() && listaConteiner.get(i).getPaisOrigem().equals("desconhecido")){
                contador++;
            }
        }
        System.out.println("Quantidade de conteiners perigoso e origem desconhecida: " + contador);
        return contador;
    }
}
