package Aula14_Mesa;

public class Principal {
    public static void main(String[] args) {

        Conteiner conteiner1 =  new Conteiner(1, "1",
                "Austrália", false, false);
        Conteiner conteiner2 =  new Conteiner(2, "2",
                "Japão", true, false);
        Conteiner conteiner3 =  new Conteiner(3, "3",
                "Desconhecido", true, true);

        Porto porto = new Porto("Santos");

        porto.addConteiner(conteiner1);
        porto.addConteiner(conteiner2);
        porto.addConteiner(conteiner3);

        porto.mostrarConteiners();

        porto.quantidadeConteinersPerigosos();
    }
}
