package Aula14_Mesa;

public class Conteiner implements Comparable<Conteiner>{

    private int numero;
    private String descricao;
    private String paisOrigem;
    private boolean materialPerigoso;
    private boolean embarcado;

    public Conteiner(int numero, String descricao, String paisOrigem, boolean materialPerigoso, boolean embarcado) {
        this.numero = numero;
        this.descricao = descricao;
        this.paisOrigem = paisOrigem;
        this.materialPerigoso = materialPerigoso;
        this.embarcado = embarcado;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getPaisOrigem() {
        return paisOrigem;
    }

    public void setPaisOrigem(String paisOrigem) {
        this.paisOrigem = paisOrigem;
    }

    public boolean isMaterialPerigoso() {
        return materialPerigoso;
    }

    public void setMaterialPerigoso(boolean materialPerigoso) {
        this.materialPerigoso = materialPerigoso;
    }

    public boolean isEmbarcado() {
        return embarcado;
    }

    public void setEmbarcado(boolean embarcado) {
        this.embarcado = embarcado;
    }

    @Override
    public int compareTo(Conteiner conteiner) {
        if (this.numero == conteiner.numero){
            return 0;
        } else if (this.numero < conteiner.numero){
            return -1;
        } else{
            return 1;
        }
    }
}
